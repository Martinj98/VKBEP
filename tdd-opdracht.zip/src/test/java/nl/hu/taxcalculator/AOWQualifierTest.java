package nl.hu.taxcalculator;

import static java.time.LocalDate.of;

import org.junit.jupiter.api.BeforeEach;

public class AOWQualifierTest {
	
	private AOWQualifier aowQualifier;
	
	@BeforeEach
	public void beforeEach() {
		aowQualifier = new AOWQualifier(of(2017,1,1));
	}

}
